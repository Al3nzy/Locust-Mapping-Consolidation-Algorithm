# HSGA: a hybrid heuristic algorithm for workflow scheduling in cloud systems
This project presents a hybrid heuristic method (HSGA) to find a suitable scheduling for workflow graph, based on genetic algorithm in order to obtain the response quickly.
Simulation was done on [Cloudsim](https://github.com/Cloudslab/cloudsim).
